export const WH: any;
